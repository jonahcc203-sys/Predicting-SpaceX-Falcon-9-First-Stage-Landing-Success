"""SpaceX Launch Records Dashboard built with Plotly Dash.

Run:  python spacex_dash_app.py   then open http://127.0.0.1:8050
"""
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html
from dash.dependencies import Input, Output

DATA_URL = ("https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/"
            "IBMDeveloperSkillsNetwork-DS0321EN-SkillsNetwork/datasets/spacex_launch_dash.csv")
try:
    spacex_df = pd.read_csv("spacex_launch_dash.csv")
except FileNotFoundError:
    spacex_df = pd.read_csv(DATA_URL)

max_payload = spacex_df["Payload Mass (kg)"].max()
min_payload = spacex_df["Payload Mass (kg)"].min()
sites = sorted(spacex_df["Launch Site"].unique())

app = Dash(__name__)

app.layout = html.Div(children=[
    html.H1("SpaceX Launch Records Dashboard",
            style={"textAlign": "center", "color": "#503D36", "font-size": 40}),

    # TASK 1: launch site drop-down
    dcc.Dropdown(
        id="site-dropdown",
        options=[{"label": "All Sites", "value": "ALL"}] + [{"label": s, "value": s} for s in sites],
        value="ALL",
        placeholder="Select a Launch Site here",
        searchable=True,
    ),
    html.Br(),

    # TASK 2: success pie chart
    html.Div(dcc.Graph(id="success-pie-chart")),
    html.Br(),

    html.P("Payload range (Kg):"),
    # TASK 3: payload range slider
    dcc.RangeSlider(
        id="payload-slider", min=0, max=10000, step=1000,
        marks={0: "0", 2500: "2500", 5000: "5000", 7500: "7500", 10000: "10000"},
        value=[min_payload, max_payload],
    ),

    # TASK 4: payload vs outcome scatter chart
    html.Div(dcc.Graph(id="success-payload-scatter-chart")),
])


@app.callback(Output("success-pie-chart", "figure"), Input("site-dropdown", "value"))
def update_pie(selected_site):
    """Pie chart of successful launches (all sites) or success vs failure (one site)."""
    if selected_site == "ALL":
        fig = px.pie(spacex_df[spacex_df["class"] == 1], names="Launch Site",
                     title="Total successful launches by site")
    else:
        site_df = spacex_df[spacex_df["Launch Site"] == selected_site]
        counts = site_df["class"].value_counts().reset_index()
        counts.columns = ["class", "count"]
        fig = px.pie(counts, names="class", values="count",
                     title=f"Success (1) vs failure (0) for site {selected_site}")
    return fig


@app.callback(
    Output("success-payload-scatter-chart", "figure"),
    [Input("site-dropdown", "value"), Input("payload-slider", "value")],
)
def update_scatter(selected_site, payload_range):
    """Scatter of payload mass vs launch outcome, coloured by booster version category."""
    low, high = payload_range
    df = spacex_df[(spacex_df["Payload Mass (kg)"] >= low) & (spacex_df["Payload Mass (kg)"] <= high)]
    if selected_site != "ALL":
        df = df[df["Launch Site"] == selected_site]
    title = "Payload vs outcome for all sites" if selected_site == "ALL" else f"Payload vs outcome for {selected_site}"
    return px.scatter(df, x="Payload Mass (kg)", y="class", color="Booster Version Category", title=title)


if __name__ == "__main__":
    app.run(debug=True)
