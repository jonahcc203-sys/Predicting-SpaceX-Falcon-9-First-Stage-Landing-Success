# IBM Data Science Capstone - SpaceX Falcon 9 First Stage Landing Prediction

Predict whether the Falcon 9 first stage will land successfully, to estimate launch cost for a competing company (SpaceY).

## Contents

| File | Purpose |
|------|---------|
| `jupyter-labs-spacex-data-collection-api.ipynb` | Collect launch data from the SpaceX REST API |
| `jupyter-labs-webscraping.ipynb` | Scrape Falcon 9 launch records from Wikipedia with BeautifulSoup |
| `labs-jupyter-spacex-Data-wrangling.ipynb` | Clean the data and create the landing `Class` label |
| `jupyter-labs-eda-sql-coursera_sqllite.ipynb` | Exploratory analysis with SQL (SQLite) |
| `jupyter-labs-eda-dataviz.ipynb` | Exploratory analysis with visualizations and feature engineering |
| `lab_jupyter_launch_site_location.ipynb` | Interactive map with Folium |
| `spacex_dash_app.py` | Interactive dashboard with Plotly Dash |
| `SpaceX_Machine_Learning_Prediction_Part_5.ipynb` | Classification models and comparison |

## How to run

```bash
pip install -r requirements.txt
jupyter notebook          # run the notebooks in the order listed above
python spacex_dash_app.py # dashboard at http://127.0.0.1:8050
```

Run each notebook from top to bottom (Kernel > Restart & Run All) and save it so the outputs are stored before committing.

## Author
Jonah Crispin
